package co.edu.unbosque.controller;

/**
 * 
 * @author David L�pez, Andres Marin, Esteban Uribe, Yensy Gonzalez, Camilo Gomez
 *
 *
 */
public class AplMain {
	
	/**
	 * Metodo defautl para que funcion el programa
	 * 
	 * @param args
	 */
	public static void main (String []args ) {
		Controller control = new Controller();
	}

}

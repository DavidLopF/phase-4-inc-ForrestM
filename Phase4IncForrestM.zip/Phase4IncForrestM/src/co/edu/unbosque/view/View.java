package co.edu.unbosque.view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Image;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import co.edu.unbosque.controller.Controller;

/**
 * 
 * @author David L�pez, David L�pez, Andres Marin, Esteban Uribe, Yensy Gonzalez
 *
 */
public class View extends JFrame {

	private PanelReproduccion panelReproduccion;
	private String titulo;

	/**
	 * Constructor de la clase View 
	 * @param Control control
	 */
	
	public View(Controller control) {

		setTitle(titulo);
		setSize(850, 700);
		getContentPane().setLayout(new BorderLayout());
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		inicializarComponentes();
		setResizable(false);
		setLocationRelativeTo(null);
		setVisible(false);

		// listeners botones panel reproducir

		panelReproduccion.getBtnBajar().addActionListener(control);
		panelReproduccion.getBtnBorrar().addActionListener(control);
		panelReproduccion.getBtnCrear().addActionListener(control);
		panelReproduccion.getBtnEditar().addActionListener(control);
		panelReproduccion.getBtnPlay().addActionListener(control);
		panelReproduccion.getBtnSiguiente().addActionListener(control);
		panelReproduccion.getBtnStop().addActionListener(control);
		panelReproduccion.getBtnStop().addActionListener(control);
		panelReproduccion.getBtnSubir().addActionListener(control);
		panelReproduccion.getCbbModo().addActionListener(control);

	}
	/**
	 * inicializa los paneles del Jframe
	 */

	public void inicializarComponentes() {

		panelReproduccion = new PanelReproduccion();
		add(panelReproduccion, BorderLayout.CENTER);
	}
	
	/**
	 * Obtiene atributo panelReproduccion de la clase view
	 * @return panelReproduccion
	 */

	public PanelReproduccion getPanelReproduccion() {
		return panelReproduccion;
	}
	/**
	 * Modifica el atributo PanelReproducci�n de la clase view
	 * @param panelReproducci�n
	 */

	public void setPanelReproduccion(PanelReproduccion panelReproducci�n) {
		this.panelReproduccion = panelReproducci�n;
	}

	// METODO PARA IMPRIMIR MENSAJES
	
	/**
	 * Imprime un Stirng en JOptionPane
	 * @param String a 
	 * @param String titulo
	 */

	public void imprimirMensaje(String a, String titulo) {

		JOptionPane.showInternalMessageDialog(null, a, titulo, JOptionPane.INFORMATION_MESSAGE);
	}

	// METODO PARA PERDIR DATOS
	
	/**
	 * Pide un dato en un jOptionPane
	 * @param a  
	 * @param titulo
	 * @return JoptionPane
	 */

	public String pedirDato(String a, String titulo) {
		return (JOptionPane.showInputDialog(null, a, titulo, JOptionPane.INFORMATION_MESSAGE));
	}
	
	/**
	 * Cambia las imagen que se carga en jLabel
	 * @param String d
	 * @param JLabel a
	 */

	public void cambiarImagen(String d, JLabel a) {
		ImageIcon im = new ImageIcon("./Data/Imagenes/" + d + ".png");
		ImageIcon icono = new ImageIcon(
				im.getImage().getScaledInstance(this.getWidth() - 500, this.getHeight() - 500, Image.SCALE_DEFAULT));
		a.setIcon(icono);

	}

}
